import React from 'react';
import ServicesComponent from '../components/Services';
import Technologies from '../components/Technologies';

const Services = () => {
  return (
    <div className="pt-16">
      <div className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">Our Services</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Comprehensive IT solutions tailored to drive your business forward in the digital age
          </p>
        </div>
      </div>
      <ServicesComponent />
      <Technologies />
    </div>
  );
};

export default Services;