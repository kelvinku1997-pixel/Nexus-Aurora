import React, { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { 
  Shield, 
  Search, 
  Bug,
  FileCheck, 
  AlertTriangle,
  CheckCircle,
  ArrowRight,
  Lock,
  Eye,
  Award,
  Clock
} from 'lucide-react';

const Cybersecurity = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in-up');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.scroll-animate');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      title: 'Security Audits',
      description: 'Comprehensive evaluation of your IT infrastructure to identify vulnerabilities and security gaps. Our expert team conducts thorough assessments of your systems, networks, and applications to ensure they meet industry security standards.',
      icon: Search,
      color: 'from-blue-500 to-blue-600',
      features: ['Network Security Assessment', 'Application Security Review', 'Infrastructure Analysis', 'Risk Assessment Report']
    },
    {
      title: 'Penetration Testing',
      description: 'Ethical hacking services that simulate real-world cyber attacks to test your defenses. We identify weaknesses before malicious actors do, providing detailed reports and remediation strategies.',
      icon: Bug,
      color: 'from-red-500 to-red-600',
      features: ['Web Application Testing', 'Network Penetration Testing', 'Social Engineering Tests', 'Wireless Security Testing']
    },
    {
      title: 'Compliance',
      description: 'Ensure your organization meets regulatory requirements and industry standards. We help you achieve and maintain compliance with frameworks like GDPR, HIPAA, PCI-DSS, and ISO 27001.',
      icon: FileCheck,
      color: 'from-green-500 to-green-600',
      features: ['GDPR Compliance', 'HIPAA Compliance', 'PCI-DSS Certification', 'ISO 27001 Implementation']
    },
    {
      title: 'Incident Response',
      description: 'Rapid response services for security breaches and cyber incidents. Our 24/7 incident response team helps contain threats, minimize damage, and restore normal operations quickly.',
      icon: AlertTriangle,
      color: 'from-orange-500 to-orange-600',
      features: ['24/7 Emergency Response', 'Forensic Analysis', 'Threat Containment', 'Recovery Planning']
    }
  ];

  const benefits = [
    {
      icon: Lock,
      title: 'Advanced Protection',
      description: 'Multi-layered security approach to protect against sophisticated cyber threats'
    },
    {
      icon: Eye,
      title: 'Continuous Monitoring',
      description: '24/7 security monitoring and threat detection to identify risks in real-time'
    },
    {
      icon: Award,
      title: 'Expert Team',
      description: 'Certified security professionals with extensive experience in cybersecurity'
    },
    {
      icon: Clock,
      title: 'Rapid Response',
      description: 'Quick incident response to minimize impact and restore operations'
    }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-red-600 to-purple-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6">
            <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-semibold">
              <Shield className="h-4 w-4" />
              <span>Cybersecurity Solutions</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">Cybersecurity Services</h1>
            <p className="text-xl text-red-100 max-w-4xl mx-auto leading-relaxed">
              Comprehensive security solutions to protect your business from evolving cyber threats. 
              Safeguard your digital assets with our expert cybersecurity services.
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <section ref={sectionRef} className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div className="space-y-6 scroll-animate opacity-0 translate-x-[-50px] transition-all duration-700">
              <h2 className="text-4xl font-bold text-gray-900">
                Why Cybersecurity Matters
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  In today's digital landscape, cyber threats are constantly evolving and becoming more sophisticated. 
                  Businesses of all sizes are at risk of data breaches, ransomware attacks, and other cyber incidents 
                  that can cause significant financial and reputational damage.
                </p>
                <p>
                  Our comprehensive cybersecurity services provide multi-layered protection to safeguard your business 
                  from these threats. We combine cutting-edge technology with expert knowledge to create robust security 
                  frameworks tailored to your specific needs.
                </p>
                <p className="font-semibold text-gray-900">
                  Don't wait for a security incident to happen. Protect your business with proactive cybersecurity measures.
                </p>
              </div>
            </div>
            
            <div className="relative scroll-animate opacity-0 translate-x-[50px] transition-all duration-700 delay-300">
              <img 
                src="https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Cybersecurity Services" 
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-red-600/20 to-transparent rounded-2xl"></div>
            </div>
          </div>

          {/* Benefits Section */}
          <div className="mb-20">
            <div className="text-center mb-12 scroll-animate opacity-0 translate-y-8 transition-all duration-700">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Key Benefits</h3>
              <p className="text-xl text-gray-600">
                Protect your business with our comprehensive cybersecurity approach
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {benefits.map((benefit, index) => {
                const IconComponent = benefit.icon;
                return (
                  <div 
                    key={index} 
                    className="text-center p-6 bg-slate-50 rounded-xl hover:shadow-lg transition-all duration-300 hover:-translate-y-2 scroll-animate opacity-0 translate-y-8"
                    style={{ transitionDelay: `${index * 150}ms` }}
                  >
                    <div className="h-16 w-16 bg-gradient-to-br from-red-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">{benefit.title}</h4>
                    <p className="text-gray-600">{benefit.description}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Services Section */}
          <div>
            <div className="text-center mb-12 scroll-animate opacity-0 translate-y-8 transition-all duration-700">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Our Cybersecurity Services</h3>
              <p className="text-xl text-gray-600">
                Comprehensive security solutions tailored to protect your business
              </p>
            </div>

            <div className="space-y-8">
              {services.map((service, index) => {
                const IconComponent = service.icon;
                return (
                  <div 
                    key={index} 
                    className="bg-white border border-gray-200 rounded-2xl p-8 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 scroll-animate opacity-0 translate-y-8"
                    style={{ transitionDelay: `${index * 200}ms` }}
                  >
                    <div className="flex items-start space-x-6">
                      <div className={`h-16 w-16 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center flex-shrink-0`}>
                        <IconComponent className="h-8 w-8 text-white" />
                      </div>
                      
                      <div className="flex-1 space-y-4">
                        <h4 className="text-2xl font-bold text-gray-900">{service.title}</h4>
                        <p className="text-gray-600 leading-relaxed text-lg">
                          {service.description}
                        </p>
                        <div className="grid md:grid-cols-2 gap-2">
                          {service.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center space-x-2">
                              <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                              <span className="text-gray-700 text-sm">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-red-600 to-purple-600 scroll-animate opacity-0 translate-y-8 transition-all duration-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-8">
            <h3 className="text-4xl font-bold text-white">
              Secure Your Business Today
            </h3>
            <p className="text-xl text-red-100 max-w-3xl mx-auto">
              Don't leave your business vulnerable to cyber threats. Contact our cybersecurity experts 
              to discuss how we can protect your digital assets and ensure business continuity.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-red-600 px-8 py-4 rounded-full font-semibold hover:bg-red-50 transition-colors flex items-center justify-center space-x-2">
                <span>Get Security Assessment</span>
                <ArrowRight className="h-5 w-5" />
              </button>
              <button className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-red-600 transition-colors">
                Contact Security Team
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Cybersecurity;