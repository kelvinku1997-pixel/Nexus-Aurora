import React from 'react';
import AboutComponent from '../components/About';
import { Users, Award, Globe, Clock } from 'lucide-react';

const About = () => {
  return (
    <div className="pt-16">
      <div className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">About Nexus Aurora</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            A Trusted Technology Partner in APAC with over 17 years of proven experience
          </p>
        </div>
      </div>
      <AboutComponent />
      
      {/* Additional About Content */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose Nexus Aurora?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              With a clear mission to bridge regional expertise with global technologies, we accelerate success for technology providers, channel partners, and businesses across Asia Pacific region
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-slate-50 rounded-xl">
              <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Proven Experience</h3>
              <p className="text-gray-600">17+ years of delivering trusted IT solutions across APAC</p>
            </div>
            
            <div className="text-center p-6 bg-slate-50 rounded-xl">
              <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">ISO Certified</h3>
              <p className="text-gray-600">ISO/IEC 27001:2022 certified for information security</p>
            </div>
            
            <div className="text-center p-6 bg-slate-50 rounded-xl">
              <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Regional Expertise</h3>
              <p className="text-gray-600">Deep understanding of APAC markets and compliance requirements</p>
            </div>
            
            <div className="text-center p-6 bg-slate-50 rounded-xl">
              <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Trusted by SMEs</h3>
              <p className="text-gray-600">500+ SME clients across banking, retail, logistics sectors</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;