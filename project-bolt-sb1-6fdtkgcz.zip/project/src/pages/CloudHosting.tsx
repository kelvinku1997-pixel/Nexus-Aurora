import React, { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { 
  Cloud, 
  Server, 
  Globe,
  Mail, 
  Shield,
  CheckCircle,
  ArrowRight,
  Zap,
  Users,
  Award,
  Clock
} from 'lucide-react';

const CloudHosting = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in-up');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.scroll-animate');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      title: 'Shared Hosting',
      description: 'Cost-effective hosting solution perfect for small businesses and personal websites. Share server resources with other websites while maintaining excellent performance and reliability.',
      icon: Globe,
      color: 'from-blue-500 to-blue-600',
      features: ['99.9% Uptime Guarantee', 'Free SSL Certificate', 'One-Click WordPress Install', 'Email Accounts Included', '24/7 Technical Support']
    },
    {
      title: 'Dedicated Servers',
      description: 'Complete server resources dedicated exclusively to your business. Maximum performance, security, and control for high-traffic websites and applications.',
      icon: Server,
      color: 'from-purple-500 to-purple-600',
      features: ['Full Root Access', 'Custom Server Configuration', 'High-Performance Hardware', 'Advanced Security Features', 'Managed Server Options']
    },
    {
      title: 'Web Hosting',
      description: 'Professional web hosting solutions designed to keep your website fast, secure, and always accessible. Perfect for businesses of all sizes.',
      icon: Cloud,
      color: 'from-green-500 to-green-600',
      features: ['SSD Storage', 'Free Domain Registration', 'Website Builder Tools', 'Multiple PHP Versions', 'Database Support']
    },
    {
      title: 'Email Services',
      description: 'Professional email hosting with your custom domain. Secure, reliable email communication for your business with advanced spam protection.',
      icon: Mail,
      color: 'from-orange-500 to-orange-600',
      features: ['Custom Domain Email', 'Spam & Virus Protection', 'Mobile Device Sync', 'Large Mailbox Storage', 'Email Forwarding']
    },
    {
      title: 'Backup & Disaster Recovery',
      description: 'Comprehensive backup solutions to protect your data and ensure business continuity. Automated backups with quick recovery options.',
      icon: Shield,
      color: 'from-red-500 to-red-600',
      features: ['Automated Daily Backups', 'One-Click Restore', 'Offsite Storage', 'Version Control', 'Disaster Recovery Planning']
    }
  ];

  const benefits = [
    {
      icon: Zap,
      title: 'High Performance',
      description: 'Lightning-fast servers with SSD storage and optimized configurations'
    },
    {
      icon: Shield,
      title: 'Enterprise Security',
      description: 'Advanced security measures including firewalls, DDoS protection, and SSL certificates'
    },
    {
      icon: Users,
      title: 'Expert Support',
      description: '24/7 technical support from certified hosting professionals'
    },
    {
      icon: Award,
      title: 'Proven Reliability',
      description: '99.9% uptime guarantee with redundant infrastructure and monitoring'
    }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-blue-600 to-cyan-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6">
            <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-semibold">
              <Cloud className="h-4 w-4" />
              <span>Cloud Hosting Solutions</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">Cloud Hosting Services</h1>
            <p className="text-xl text-blue-100 max-w-4xl mx-auto leading-relaxed">
              We provide your business with the domain, website, and email hosting it needs. Solutions include a range of services, 
              including basic web hosting for individuals and entrepreneurs, email, e-commerce, VPS server, and dedicated server hosting.
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <section ref={sectionRef} className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div className="space-y-6 scroll-animate opacity-0 translate-x-[-50px] transition-all duration-700">
              <h2 className="text-4xl font-bold text-gray-900">
                Why Choose Our Cloud Hosting?
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  In today's digital world, reliable hosting is crucial for business success. Our cloud hosting solutions 
                  provide the perfect balance of performance, security, and affordability to keep your online presence 
                  running smoothly 24/7.
                </p>
                <p>
                  Whether you're launching your first website or managing enterprise-level applications, our hosting 
                  infrastructure scales with your needs. We offer everything from shared hosting for startups to 
                  dedicated servers for high-traffic websites.
                </p>
                <p className="font-semibold text-gray-900">
                  Experience the difference with our enterprise-grade hosting solutions backed by expert support.
                </p>
              </div>
            </div>
            
            <div className="relative scroll-animate opacity-0 translate-x-[50px] transition-all duration-700 delay-300">
              <img 
                src="https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Cloud Hosting Services" 
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-600/20 to-transparent rounded-2xl"></div>
            </div>
          </div>

          {/* Benefits Section */}
          <div className="mb-20">
            <div className="text-center mb-12 scroll-animate opacity-0 translate-y-8 transition-all duration-700">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Key Benefits</h3>
              <p className="text-xl text-gray-600">
                Why thousands of businesses trust our hosting solutions
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {benefits.map((benefit, index) => {
                const IconComponent = benefit.icon;
                return (
                  <div 
                    key={index} 
                    className="text-center p-6 bg-slate-50 rounded-xl hover:shadow-lg transition-all duration-300 hover:-translate-y-2 scroll-animate opacity-0 translate-y-8"
                    style={{ transitionDelay: `${index * 150}ms` }}
                  >
                    <div className="h-16 w-16 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">{benefit.title}</h4>
                    <p className="text-gray-600">{benefit.description}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Services Section */}
          <div>
            <div className="text-center mb-12 scroll-animate opacity-0 translate-y-8 transition-all duration-700">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Our Hosting Services</h3>
              <p className="text-xl text-gray-600">
                Complete hosting solutions tailored to your business needs
              </p>
            </div>

            <div className="space-y-8">
              {services.map((service, index) => {
                const IconComponent = service.icon;
                return (
                  <div 
                    key={index} 
                    className="bg-white border border-gray-200 rounded-2xl p-8 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 scroll-animate opacity-0 translate-y-8"
                    style={{ transitionDelay: `${index * 200}ms` }}
                  >
                    <div className="flex items-start space-x-6">
                      <div className={`h-16 w-16 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center flex-shrink-0`}>
                        <IconComponent className="h-8 w-8 text-white" />
                      </div>
                      
                      <div className="flex-1 space-y-4">
                        <h4 className="text-2xl font-bold text-gray-900">{service.title}</h4>
                        <p className="text-gray-600 leading-relaxed text-lg">
                          {service.description}
                        </p>
                        <div className="grid md:grid-cols-2 gap-2">
                          {service.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center space-x-2">
                              <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                              <span className="text-gray-700 text-sm">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-cyan-600 scroll-animate opacity-0 translate-y-8 transition-all duration-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-8">
            <h3 className="text-4xl font-bold text-white">
              Ready to Host Your Website?
            </h3>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Get started with our reliable hosting solutions today. Choose the perfect plan for your business 
              and experience the difference of professional hosting.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-blue-50 transition-colors flex items-center justify-center space-x-2">
                <span>View Hosting Plans</span>
                <ArrowRight className="h-5 w-5" />
              </button>
              <button className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-colors">
                Contact Sales Team
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CloudHosting;