import React, { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { 
  Server, 
  Database, 
  Shield,
  Network, 
  HardDrive,
  CheckCircle,
  ArrowRight,
  Zap,
  Award,
  Clock,
  Users
} from 'lucide-react';

const SystemServers = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in-up');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.scroll-animate');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      title: 'Server Consolidation',
      description: 'Optimize your IT infrastructure by consolidating multiple servers into fewer, more powerful systems. Reduce hardware costs, energy consumption, and management complexity while improving performance and reliability.',
      icon: Server,
      color: 'from-blue-500 to-blue-600',
      features: ['Hardware Cost Reduction', 'Energy Efficiency', 'Simplified Management', 'Improved Performance', 'Space Optimization']
    },
    {
      title: 'Microsoft Solution',
      description: 'Comprehensive Microsoft server solutions including Windows Server, Active Directory, Exchange Server, and SharePoint. Leverage the power of Microsoft ecosystem for seamless integration and productivity.',
      icon: Database,
      color: 'from-green-500 to-green-600',
      features: ['Windows Server Implementation', 'Active Directory Services', 'Exchange Server Setup', 'SharePoint Solutions', 'Microsoft Licensing']
    },
    {
      title: 'Backup Solution',
      description: 'Robust backup and disaster recovery solutions to protect your critical business data. Automated backup schedules, offsite storage, and rapid recovery capabilities ensure business continuity.',
      icon: Shield,
      color: 'from-orange-500 to-orange-600',
      features: ['Automated Backup Scheduling', 'Offsite Storage Options', 'Rapid Recovery Systems', 'Data Integrity Verification', 'Disaster Recovery Planning']
    },
    {
      title: 'Server and Server Integration',
      description: 'Seamless integration of new servers with existing infrastructure. Ensure compatibility, optimize performance, and maintain security across your entire server environment.',
      icon: Network,
      color: 'from-purple-500 to-purple-600',
      features: ['Infrastructure Assessment', 'Compatibility Testing', 'Performance Optimization', 'Security Integration', 'Migration Services']
    },
    {
      title: 'Virtualization Solution',
      description: 'Transform your physical servers into virtual environments for better resource utilization, flexibility, and cost savings. Implement VMware, Hyper-V, or other virtualization technologies.',
      icon: HardDrive,
      color: 'from-red-500 to-red-600',
      features: ['VMware Implementation', 'Hyper-V Solutions', 'Resource Optimization', 'Virtual Machine Management', 'High Availability Setup']
    }
  ];

  const benefits = [
    {
      icon: Zap,
      title: 'Enhanced Performance',
      description: 'Optimized server configurations for maximum performance and efficiency'
    },
    {
      icon: Shield,
      title: 'Robust Security',
      description: 'Enterprise-grade security measures to protect your server infrastructure'
    },
    {
      icon: Users,
      title: 'Expert Support',
      description: '24/7 technical support from certified server administrators'
    },
    {
      icon: Award,
      title: 'Lower TCO',
      description: 'Reduced Total Cost of Ownership through optimized design and implementation'
    }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-gray-700 to-blue-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6">
            <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-semibold">
              <Server className="h-4 w-4" />
              <span>System Server Solutions</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">System Servers</h1>
            <p className="text-xl text-blue-100 max-w-4xl mx-auto leading-relaxed">
              System solutions are the foundation to any company, with a roadmap for stability and scalability 
              as key components to the system. Our consulting approach is based on lower TCO design for our clients.
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <section ref={sectionRef} className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div className="space-y-6 scroll-animate opacity-0 translate-x-[-50px] transition-all duration-700">
              <h2 className="text-4xl font-bold text-gray-900">
                Why System Servers Matter
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  In today's digital business environment, reliable server infrastructure is the backbone of 
                  organizational success. Our system server solutions provide the stability, scalability, 
                  and performance your business needs to thrive.
                </p>
                <p>
                  We understand that every organization has unique requirements. Our approach focuses on 
                  designing cost-effective solutions that not only meet your current needs but also provide 
                  a clear path for future growth and expansion.
                </p>
                <p className="font-semibold text-gray-900">
                  Build a solid foundation for your business with our expert system server solutions.
                </p>
              </div>
            </div>
            
            <div className="relative scroll-animate opacity-0 translate-x-[50px] transition-all duration-700 delay-300">
              <img 
                src="https://images.pexels.com/photos/325229/pexels-photo-325229.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="System Server Solutions" 
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-600/20 to-transparent rounded-2xl"></div>
            </div>
          </div>

          {/* Benefits Section */}
          <div className="mb-20">
            <div className="text-center mb-12 scroll-animate opacity-0 translate-y-8 transition-all duration-700">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Key Benefits</h3>
              <p className="text-xl text-gray-600">
                Why businesses choose our system server solutions
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {benefits.map((benefit, index) => {
                const IconComponent = benefit.icon;
                return (
                  <div 
                    key={index} 
                    className="text-center p-6 bg-slate-50 rounded-xl hover:shadow-lg transition-all duration-300 hover:-translate-y-2 scroll-animate opacity-0 translate-y-8"
                    style={{ transitionDelay: `${index * 150}ms` }}
                  >
                    <div className="h-16 w-16 bg-gradient-to-br from-gray-600 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">{benefit.title}</h4>
                    <p className="text-gray-600">{benefit.description}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Services Section */}
          <div>
            <div className="text-center mb-12 scroll-animate opacity-0 translate-y-8 transition-all duration-700">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Our System Server Solutions</h3>
              <p className="text-xl text-gray-600">
                Comprehensive server solutions designed for stability and scalability
              </p>
            </div>

            <div className="space-y-8">
              {services.map((service, index) => {
                const IconComponent = service.icon;
                return (
                  <div 
                    key={index} 
                    className="bg-white border border-gray-200 rounded-2xl p-8 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 scroll-animate opacity-0 translate-y-8"
                    style={{ transitionDelay: `${index * 200}ms` }}
                  >
                    <div className="flex items-start space-x-6">
                      <div className={`h-16 w-16 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center flex-shrink-0`}>
                        <IconComponent className="h-8 w-8 text-white" />
                      </div>
                      
                      <div className="flex-1 space-y-4">
                        <h4 className="text-2xl font-bold text-gray-900">{service.title}</h4>
                        <p className="text-gray-600 leading-relaxed text-lg">
                          {service.description}
                        </p>
                        <div className="grid md:grid-cols-2 gap-2">
                          {service.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center space-x-2">
                              <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                              <span className="text-gray-700 text-sm">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-700 to-blue-600 scroll-animate opacity-0 translate-y-8 transition-all duration-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-8">
            <h3 className="text-4xl font-bold text-white">
              Ready to Optimize Your Server Infrastructure?
            </h3>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Let our server experts design a solution that provides stability, scalability, 
              and cost-effectiveness for your business operations.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-gray-700 px-8 py-4 rounded-full font-semibold hover:bg-gray-50 transition-colors flex items-center justify-center space-x-2">
                <span>Get Server Assessment</span>
                <ArrowRight className="h-5 w-5" />
              </button>
              <button className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-gray-700 transition-colors">
                Contact Server Team
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SystemServers;