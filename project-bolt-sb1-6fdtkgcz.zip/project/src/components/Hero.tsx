import React from 'react';
import { ArrowRight, Play, Star, Users, Award, TrendingUp } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-16 overflow-hidden w-full">
      {/* IT Company Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.pexels.com/photos/325229/pexels-photo-325229.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop" 
          alt="IT Server Room Background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/85 via-slate-900/80 to-purple-900/85"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
      </div>
      
      {/* Animated Network Background */}
      <div className="absolute inset-0 opacity-20 z-10 overflow-hidden">
        <svg className="w-full h-full" viewBox="0 0 1200 800" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Network Switches */}
          <rect x="100" y="200" width="80" height="40" rx="4" fill="#60A5FA" className="animate-pulse" />
          <rect x="300" y="150" width="80" height="40" rx="4" fill="#60A5FA" className="animate-pulse" style={{animationDelay: '0.5s'}} />
          <rect x="500" y="300" width="80" height="40" rx="4" fill="#60A5FA" className="animate-pulse" style={{animationDelay: '1s'}} />
          <rect x="700" y="180" width="80" height="40" rx="4" fill="#60A5FA" className="animate-pulse" style={{animationDelay: '1.5s'}} />
          <rect x="900" y="250" width="80" height="40" rx="4" fill="#60A5FA" className="animate-pulse" style={{animationDelay: '2s'}} />
          
          {/* Switch Ports */}
          <circle cx="120" cy="220" r="3" fill="#34D399" className="animate-ping" />
          <circle cx="135" cy="220" r="3" fill="#34D399" className="animate-ping" style={{animationDelay: '0.3s'}} />
          <circle cx="150" cy="220" r="3" fill="#34D399" className="animate-ping" style={{animationDelay: '0.6s'}} />
          <circle cx="165" cy="220" r="3" fill="#34D399" className="animate-ping" style={{animationDelay: '0.9s'}} />
          
          <circle cx="320" cy="170" r="3" fill="#34D399" className="animate-ping" style={{animationDelay: '0.2s'}} />
          <circle cx="335" cy="170" r="3" fill="#34D399" className="animate-ping" style={{animationDelay: '0.5s'}} />
          <circle cx="350" cy="170" r="3" fill="#34D399" className="animate-ping" style={{animationDelay: '0.8s'}} />
          <circle cx="365" cy="170" r="3" fill="#34D399" className="animate-ping" style={{animationDelay: '1.1s'}} />
          
          <circle cx="520" cy="320" r="3" fill="#34D399" className="animate-ping" style={{animationDelay: '0.4s'}} />
          <circle cx="535" cy="320" r="3" fill="#34D399" className="animate-ping" style={{animationDelay: '0.7s'}} />
          <circle cx="550" cy="320" r="3" fill="#34D399" className="animate-ping" style={{animationDelay: '1s'}} />
          <circle cx="565" cy="320" r="3" fill="#34D399" className="animate-ping" style={{animationDelay: '1.3s'}} />
          
          {/* Network Cables */}
          <path d="M180 220 Q250 180 300 170" stroke="#A78BFA" strokeWidth="3" fill="none" className="animate-pulse" strokeDasharray="10,5">
            <animate attributeName="stroke-dashoffset" values="0;-15" dur="2s" repeatCount="indefinite" />
          </path>
          <path d="M380 170 Q450 200 500 320" stroke="#A78BFA" strokeWidth="3" fill="none" className="animate-pulse" strokeDasharray="10,5" style={{animationDelay: '0.5s'}}>
            <animate attributeName="stroke-dashoffset" values="0;-15" dur="2s" repeatCount="indefinite" begin="0.5s" />
          </path>
          <path d="M580 320 Q650 250 700 200" stroke="#A78BFA" strokeWidth="3" fill="none" className="animate-pulse" strokeDasharray="10,5" style={{animationDelay: '1s'}}>
            <animate attributeName="stroke-dashoffset" values="0;-15" dur="2s" repeatCount="indefinite" begin="1s" />
          </path>
          <path d="M780 200 Q850 225 900 270" stroke="#A78BFA" strokeWidth="3" fill="none" className="animate-pulse" strokeDasharray="10,5" style={{animationDelay: '1.5s'}}>
            <animate attributeName="stroke-dashoffset" values="0;-15" dur="2s" repeatCount="indefinite" begin="1.5s" />
          </path>
          
          {/* Data Flow Indicators */}
          <circle cx="0" cy="0" r="4" fill="#FBBF24">
            <animateMotion dur="3s" repeatCount="indefinite" path="M180 220 Q250 180 300 170" />
          </circle>
          <circle cx="0" cy="0" r="4" fill="#FBBF24">
            <animateMotion dur="3s" repeatCount="indefinite" path="M380 170 Q450 200 500 320" begin="0.5s" />
          </circle>
          <circle cx="0" cy="0" r="4" fill="#FBBF24">
            <animateMotion dur="3s" repeatCount="indefinite" path="M580 320 Q650 250 700 200" begin="1s" />
          </circle>
          <circle cx="0" cy="0" r="4" fill="#FBBF24">
            <animateMotion dur="3s" repeatCount="indefinite" path="M780 200 Q850 225 900 270" begin="1.5s" />
          </circle>
          
          {/* Additional Network Elements */}
          <rect x="50" y="400" width="60" height="30" rx="3" fill="#A78BFA" className="animate-pulse" style={{animationDelay: '0.8s'}} />
          <rect x="200" y="450" width="60" height="30" rx="3" fill="#A78BFA" className="animate-pulse" style={{animationDelay: '1.2s'}} />
          <rect x="400" y="500" width="60" height="30" rx="3" fill="#A78BFA" className="animate-pulse" style={{animationDelay: '1.6s'}} />
          <rect x="600" y="480" width="60" height="30" rx="3" fill="#A78BFA" className="animate-pulse" style={{animationDelay: '2.2s'}} />
          
          {/* Server Racks */}
          <rect x="1000" y="100" width="40" height="120" rx="4" fill="#6B7280" className="animate-pulse" style={{animationDelay: '0.3s'}} />
          <rect x="1060" y="100" width="40" height="120" rx="4" fill="#6B7280" className="animate-pulse" style={{animationDelay: '0.7s'}} />
          
          {/* Server Status Lights */}
          <circle cx="1020" cy="130" r="2" fill="#34D399" className="animate-ping" style={{animationDelay: '0.1s'}} />
          <circle cx="1020" cy="150" r="2" fill="#34D399" className="animate-ping" style={{animationDelay: '0.4s'}} />
          <circle cx="1020" cy="170" r="2" fill="#34D399" className="animate-ping" style={{animationDelay: '0.7s'}} />
          <circle cx="1080" cy="130" r="2" fill="#34D399" className="animate-ping" style={{animationDelay: '0.2s'}} />
          <circle cx="1080" cy="150" r="2" fill="#34D399" className="animate-ping" style={{animationDelay: '0.5s'}} />
          <circle cx="1080" cy="170" r="2" fill="#34D399" className="animate-ping" style={{animationDelay: '0.8s'}} />
        </svg>
      </div>
      
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 w-full min-w-0">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-blue-400 font-semibold">
                <Star className="h-5 w-5 fill-current" />
                <span>Trusted IT Solutions Provider</span>
              </div>
              <h1 className="text-5xl lg:text-7xl font-bold text-white leading-tight">
                Innovating
                <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  {' '}Digital{' '}
                </span>
                Excellence
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed max-w-2xl break-words">
                We transform businesses through cutting-edge technology solutions. From web development to cloud infrastructure, we deliver innovation that drives growth.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <button className="group bg-blue-600 text-white px-8 py-4 rounded-full hover:bg-blue-700 transition-all duration-300 flex items-center space-x-2 shadow-lg hover:shadow-xl">
                <span className="font-semibold">Start Your Project</span>
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </button>
              {/*<button className="group bg-white text-gray-900 px-8 py-4 rounded-full border-2 border-gray-200 hover:border-blue-600 transition-all duration-300 flex items-center space-x-2 shadow-lg hover:shadow-xl">
                <Play className="h-5 w-5 text-blue-600" />
                <span className="font-semibold">Watch Demo</span>
              </button>*/}
            </div>

            <div className="flex items-center space-x-8 pt-8">
              <div className="flex items-center space-x-2">
                <Users className="h-6 w-6 text-blue-400" />
                <div>
                  <div className="text-2xl font-bold text-white">500+</div>
                  <div className="text-gray-300">Happy Clients</div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Award className="h-6 w-6 text-blue-400" />
                <div>
                  <div className="text-2xl font-bold text-white">50+</div>
                  <div className="text-gray-300">Awards Won</div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-6 w-6 text-blue-400" />
                <div>
                  <div className="text-2xl font-bold text-white">99%</div>
                  <div className="text-gray-300">Success Rate</div>
                </div>
              </div>
            </div>
          </div>

          <div className="relative w-full min-w-0">
            <div className="relative bg-gradient-to-br from-blue-600 to-purple-600 rounded-3xl p-8 shadow-2xl">
              <div className="bg-white rounded-2xl p-8 space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="text-sm text-gray-500">Active Projects</div>
                    <div className="text-2xl font-bold text-gray-900">28</div>
                  </div>
                  <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center">
                    <TrendingUp className="h-6 w-6 text-green-600" />
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">IT consultancy</span>
                    <span className="text-gray-900 font-semibold">89%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '89%' }}></div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Web Development</span>
                    <span className="text-gray-900 font-semibold">75%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-red-600 h-2 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Mobile Apps</span>
                    <span className="text-gray-900 font-semibold">60%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-purple-600 h-2 rounded-full" style={{ width: '60%' }}></div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Cloud Solutions</span>
                    <span className="text-gray-900 font-semibold">85%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: '85%' }}></div>
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 bg-yellow-400 text-yellow-900 px-4 py-2 rounded-full text-sm font-semibold shadow-lg">
                24/7 Support
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-blue-600/30 to-purple-600/30 rounded-3xl blur-xl -z-10"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;