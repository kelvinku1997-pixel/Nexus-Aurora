import React, { useEffect, useRef } from 'react';
import { ExternalLink, Github, ArrowRight, Star } from 'lucide-react';

const Portfolio = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in-up');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.scroll-animate');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const projects = [
    {
      title: 'Ralf Darian & Co',
      category: 'Web Development',
      description: 'Empowering businesses with strategic insights, operational excellence, and transformative solutions that drive sustainable growth and competitive advantage.',
      image: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['React', 'Node.js', 'PostgreSQL', 'Stripe'],
      rating: 4.9,
      client: 'Ralf Darian & Co',
      link: 'https://ralf-darian.com/'
    },
    {
      title: 'Eternal Elegance',
      category: 'Web Development',
      description: 'A beautiful and elegant wedding planning website with modern design, featuring venue showcases, service packages, and client testimonials.',
      image: 'https://images.pexels.com/photos/265722/pexels-photo-265722.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Vite'],
      rating: 5.0,
      client: 'Eternal Elegance',
      link: 'https://wedding-company-webs-km4n.bolt.host'
    },
    {
      title: 'Healthcare Mobile App',
      category: 'Mobile Development',
      description: 'A patient management system with telemedicine capabilities and real-time health monitoring.',
      image: 'https://images.pexels.com/photos/4173624/pexels-photo-4173624.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['React Native', 'Firebase', 'WebRTC', 'MongoDB'],
      rating: 4.8,
      client: 'MediCare Plus'
    },
    {
      title: 'Financial Dashboard',
      category: 'Web Application',
      description: 'Real-time financial analytics dashboard with advanced data visualization and reporting capabilities.',
      image: 'https://images.pexels.com/photos/590016/pexels-photo-590016.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['Vue.js', 'Python', 'D3.js', 'AWS'],
      rating: 5.0,
      client: 'InvestSmart Corp'
    },
    {
      title: 'Cloud Infrastructure',
      category: 'DevOps & Cloud',
      description: 'Scalable cloud architecture with automated deployment pipelines and monitoring solutions.',
      image: 'https://images.pexels.com/photos/1181472/pexels-photo-1181472.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['AWS', 'Docker', 'Kubernetes', 'Jenkins'],
      rating: 4.9,
      client: 'TechStart Inc.'
    },
    {
      title: 'Restaurant Management',
      category: 'Full Stack',
      description: 'Complete restaurant management system with POS, inventory tracking, and customer loyalty programs.',
      image: 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['Angular', 'Node.js', 'MySQL', 'Socket.io'],
      rating: 4.7,
      client: 'Gourmet Delights'
    }
  ];

  return (
    <section id="portfolio" ref={sectionRef} className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16 scroll-animate opacity-0 translate-y-8 transition-all duration-700">
          <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-semibold">
            <Star className="h-4 w-4" />
            <span>Our Portfolio</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
            Featured Projects
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our recent work and see how we've helped businesses transform their digital presence
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 scroll-animate opacity-0 translate-y-8"
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
                    {project.category}
                  </span>
                </div>
                <div className="absolute top-4 right-4 flex space-x-2">
                  <button className="p-2 bg-white/90 rounded-full hover:bg-white transition-colors">
                    <ExternalLink className="h-4 w-4 text-gray-700" />
                  </button>
                </div>
              </div>

              <div className="p-6 space-y-4">
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {project.description}
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-semibold text-gray-700">{project.rating}</span>
                  </div>
                  <span className="text-xs text-gray-500">{project.client}</span>
                </div>

                <div className="flex flex-wrap gap-2">
                  {project.technologies.slice(0, 3).map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs font-medium"
                    >
                      {tech}
                    </span>
                  ))}
                  {project.technologies.length > 3 && (
                    <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">
                      +{project.technologies.length - 3} more
                    </span>
                  )}
                </div>

                {project.link ? (
                  <a
                    href={project.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group/btn w-full flex items-center justify-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors pt-2"
                  >
                    <span>View Details</span>
                    <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                  </a>
                ) : (
                  <button className="group/btn w-full flex items-center justify-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors pt-2">
                    <span>View Details</span>
                    <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full hover:bg-blue-700 transition-colors font-semibold">
            View All Projects
          </button>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;